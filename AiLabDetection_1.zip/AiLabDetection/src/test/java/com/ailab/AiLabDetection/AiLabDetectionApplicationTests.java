package com.ailab.AiLabDetection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiLabDetectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
